﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
           Resultado = (Numero1 + Numero2);
            MessageBox.Show(Resultado.ToString());
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Número Invalido");
            }
            else
            {
                Numero1 = double.Parse(txtNumero2.Text);
            }
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            txtResultado.Text = Resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = (Numero1 - Numero2);
        }

        private void btnMultiplica_Click(object sender, EventArgs e)
        {
            Resultado = (Numero1 * Numero2);
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0 )
            {
                MessageBox.Show("Não pode dividir por 0", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNumero2.Clear();
            }
            else
                Resultado = (Numero1 / Numero2);
        }

        private void btnPotencia_Click(object sender, EventArgs e)
        {
            Resultado = Math.Pow(Numero1,Numero2);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                "Saida", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)==DialogResult.Yes) 
            {
                Close();   
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Número Invalido");
            }
            }
        }
    }

