﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pIMC
{
    public partial class Form1 : Form
    {
        Double Numero1, Numero2, Resultado;
        string Classe, Grau = "0";

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtAltura.Text, out Numero2))||(Numero2 <=0))
            {
                MessageBox.Show("Altura Invalida");
                txtAltura.Clear();
            }
        }

        private void btnIMC_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 / (Numero2 * Numero2);
            Resultado = Math.Round(Resultado,1);
            if (Resultado < 18.5)
            {
                Classe = "Magreza";
            }
            else if (Resultado < 25)
            {
                Classe = "Normal";
            }
            else if (Resultado < 30)
            {
                Classe = "Sobrepeso";
                Grau = "I";
            }
            else if (Resultado < 40)
            {
                Classe = "Obesidade";
                Grau = "II";
            }
            else 
            {
                Classe = "Obesidade Grave";
                Grau = "III";
            }
            MessageBox.Show(Resultado.ToString()+"\n"+Classe+"\nObesidade Grau "+Grau);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpa_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtPeso.Text, out Numero1))||(Numero1 <=0 ))
            {
                MessageBox.Show("Peso Invalido");
                txtPeso.Clear();
            }
        }
    }
}
