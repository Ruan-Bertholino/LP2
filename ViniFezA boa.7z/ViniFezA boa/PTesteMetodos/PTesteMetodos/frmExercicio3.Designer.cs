﻿namespace PTesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInserir1 = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.zeDaSilva = new System.Windows.Forms.Label();
            this.silvaDoZe = new System.Windows.Forms.Label();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnInserir1
            // 
            this.btnInserir1.Location = new System.Drawing.Point(79, 220);
            this.btnInserir1.Name = "btnInserir1";
            this.btnInserir1.Size = new System.Drawing.Size(229, 58);
            this.btnInserir1.TabIndex = 12;
            this.btnInserir1.Text = "Vira o Pimeiro texto";
            this.btnInserir1.UseVisualStyleBackColor = true;
            this.btnInserir1.Click += new System.EventHandler(this.btnInserir1_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(79, 126);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(229, 58);
            this.btnRemove.TabIndex = 11;
            this.btnRemove.Text = "Remover as ocorrencias do primeiro no segundo";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // zeDaSilva
            // 
            this.zeDaSilva.AutoSize = true;
            this.zeDaSilva.Location = new System.Drawing.Point(23, 32);
            this.zeDaSilva.Name = "zeDaSilva";
            this.zeDaSilva.Size = new System.Drawing.Size(74, 20);
            this.zeDaSilva.TabIndex = 10;
            this.zeDaSilva.Text = "Palavra 1";
            // 
            // silvaDoZe
            // 
            this.silvaDoZe.AutoSize = true;
            this.silvaDoZe.Location = new System.Drawing.Point(23, 83);
            this.silvaDoZe.Name = "silvaDoZe";
            this.silvaDoZe.Size = new System.Drawing.Size(74, 20);
            this.silvaDoZe.TabIndex = 9;
            this.silvaDoZe.Text = "Palavra 2";
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(101, 80);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(207, 26);
            this.txtPalavra2.TabIndex = 8;
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(101, 29);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(207, 26);
            this.txtPalavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 324);
            this.Controls.Add(this.btnInserir1);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.zeDaSilva);
            this.Controls.Add(this.silvaDoZe);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInserir1;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Label zeDaSilva;
        private System.Windows.Forms.Label silvaDoZe;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
    }
}