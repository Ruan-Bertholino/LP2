﻿namespace PTesteMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.silvaDoZe = new System.Windows.Forms.Label();
            this.zeDaSilva = new System.Windows.Forms.Label();
            this.btnTestaiguais = new System.Windows.Forms.Button();
            this.btnInserir1 = new System.Windows.Forms.Button();
            this.btnInserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(99, 62);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(207, 26);
            this.txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(99, 113);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(207, 26);
            this.txtPalavra2.TabIndex = 1;
            // 
            // silvaDoZe
            // 
            this.silvaDoZe.AutoSize = true;
            this.silvaDoZe.Location = new System.Drawing.Point(21, 116);
            this.silvaDoZe.Name = "silvaDoZe";
            this.silvaDoZe.Size = new System.Drawing.Size(74, 20);
            this.silvaDoZe.TabIndex = 2;
            this.silvaDoZe.Text = "Palavra 2";
            // 
            // zeDaSilva
            // 
            this.zeDaSilva.AutoSize = true;
            this.zeDaSilva.Location = new System.Drawing.Point(21, 65);
            this.zeDaSilva.Name = "zeDaSilva";
            this.zeDaSilva.Size = new System.Drawing.Size(74, 20);
            this.zeDaSilva.TabIndex = 3;
            this.zeDaSilva.Text = "Palavra 1";
            // 
            // btnTestaiguais
            // 
            this.btnTestaiguais.Location = new System.Drawing.Point(77, 159);
            this.btnTestaiguais.Name = "btnTestaiguais";
            this.btnTestaiguais.Size = new System.Drawing.Size(229, 58);
            this.btnTestaiguais.TabIndex = 4;
            this.btnTestaiguais.Text = "Testa se são iguais";
            this.btnTestaiguais.UseVisualStyleBackColor = true;
            this.btnTestaiguais.Click += new System.EventHandler(this.btnTestaiguais_Click);
            // 
            // btnInserir1
            // 
            this.btnInserir1.Location = new System.Drawing.Point(77, 223);
            this.btnInserir1.Name = "btnInserir1";
            this.btnInserir1.Size = new System.Drawing.Size(229, 58);
            this.btnInserir1.TabIndex = 5;
            this.btnInserir1.Text = "Inserir o primerio numero no meio do segundo";
            this.btnInserir1.UseVisualStyleBackColor = true;
            this.btnInserir1.Click += new System.EventHandler(this.btnInserir1_Click);
            // 
            // btnInserir2
            // 
            this.btnInserir2.Location = new System.Drawing.Point(77, 287);
            this.btnInserir2.Name = "btnInserir2";
            this.btnInserir2.Size = new System.Drawing.Size(229, 58);
            this.btnInserir2.TabIndex = 6;
            this.btnInserir2.Text = "Inserir ** no meo do primeiro Numero";
            this.btnInserir2.UseVisualStyleBackColor = true;
            this.btnInserir2.Click += new System.EventHandler(this.btnInserir2_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 380);
            this.Controls.Add(this.btnInserir2);
            this.Controls.Add(this.btnInserir1);
            this.Controls.Add(this.btnTestaiguais);
            this.Controls.Add(this.zeDaSilva);
            this.Controls.Add(this.silvaDoZe);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Label silvaDoZe;
        private System.Windows.Forms.Label zeDaSilva;
        private System.Windows.Forms.Button btnTestaiguais;
        private System.Windows.Forms.Button btnInserir1;
        private System.Windows.Forms.Button btnInserir2;
    }
}