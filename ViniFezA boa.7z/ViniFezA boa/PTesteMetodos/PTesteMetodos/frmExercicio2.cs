﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnTestaiguais_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPalavra1.Text, txtPalavra2.Text,true)==0)
                MessageBox.Show("As Palavras são iguais");
            else
                MessageBox.Show("Você realmente precisou de mim pra notar a diferença?");
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int BotandoNoMeio=txtPalavra2.Text.Length/2;
            txtPalavra2.Text = txtPalavra2.Text.Substring(0, BotandoNoMeio) + txtPalavra1.Text + txtPalavra2.Text.Substring(BotandoNoMeio,txtPalavra2.Text.Length-BotandoNoMeio);
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            int BotandoNoMeio = txtPalavra1.Text.Length / 2;
            txtPalavra2.Text = txtPalavra1.Text.Insert(BotandoNoMeio, "**");
        }
    }
}
