﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasse
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciar1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumHora.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFaltas.Text);

            MessageBox.Show("Nome: "+objHorista.NomeEmpregado+
                "\nMatricula: "+ objHorista.Matricula +
                "\nTempo Trabalho: " + objHorista.TempoTrabalho()+
                "\nSalario: " + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
